var app = new Vue ({
    el: '#app',
    data: {
      product: 'Socks',
      firstName: 'Vinh ',
      lastName: 'Nguyen',
      message: 'Hello, World!'
    } 
  })